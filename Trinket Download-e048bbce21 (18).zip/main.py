def my_function(parameter):
    print(parameter)

my_function("Hello!")
my_function("Bonjour!")